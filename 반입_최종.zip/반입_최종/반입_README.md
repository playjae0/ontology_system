# 반입_최종 (21회차 확장판) — 커밋 1회용

기준: 99dc94d(G6.5) 머지된 main. 폴더 구조 = 레포 경로.
구판 zip 2종(반입_21회차 구판·G6.5_반입묶음)은 폐기 — 이것 하나가 최신이다.

```bash
# ① 선행: G6.5 브랜치 PR 머지 (99dc94d → main)  ※ 아직이면 먼저
# ② 레포 루트에서:
unzip -o 반입_최종.zip && cp -r 반입_최종/* . && rm -rf 반입_최종 반입_최종.zip
git rm "G6.5_반입묶음.zip"                                              # 오업로드 정리
git rm mock/fixtures/audit_round1.json mock/fixtures/audit_round2.json  # log/로 이동됨
git diff DECISIONS.md   # 확인 3곳: D-2·D-11·D-12 행 "확정 — 세션 1 종결"
git add -A && git commit -m "허브 21회차 반입: 정본 9종(틀 v2.10·카드 v18·CH2 v2.5·CH3B v2.4·CH6 v3.1·CH7 v1.7·파서_명세 v0.6·증분0 v1.5·대장) + CLAUDE.md delta 소진 + D-2/11/12 확정 + 정리 2건" && git push
```

들어 있는 것: docs/ 9종 교체(세션 1P·세션 1 종결·판정필요-6·**증분0 v1.5 동기화** 반영 전량) · CLAUDE.md(「미반영분」 절 소진 — v1.5 편입, B1 예외 3건 갱신) · DECISIONS 3행 확정 표기 · 봉인 점검 파일 fixtures→log 이동 · zip 삭제.
이 커밋이 서면 **P1 투입 준비 완료**다 — P1 요청문은 허브가 별도 전달(§0 하강 부착 포함).
